//
//  ViewController.swift
//  modelos
//
//  Created by Alumno on 10/4/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var restaurantes : [Restaurant] = []
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurantes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaRestaurant") as! CeldaRestaurantController
        celda.lblnombre.text = restaurantes[indexPath.row].nombre
        return celda
    }
    

    override func viewDidLoad() {
        self.title = "Restaurantes"
        
        
        super.viewDidLoad()
        restaurantes.append(Restaurant (nombre: "La hamburgesa eliz", direccion: "Calle dos #123", horario: "De 12 pm a 10 pm"))
        restaurantes.append(Restaurant (nombre: "Carnitas Pelonchas", direccion: "Calle tres #123", horario: "De 10 am a 4 pm"))
        restaurantes.append(Restaurant (nombre: "Ostiones nadadores", direccion: "Calle uno #123", horario: "De 12 pm a 6 pm"))
        // Do any additional setup after loading the view.
    }


}

